<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>As you enter the first door, you feel a bright light come to your face. You've arrived at the capital of Certacila! You are free to do your business</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "building"],
        ["type" => "door", "link" => "index.php"],
        ["type" => "building"] ];


        foreach ($elements as $element) {
            if ($element["type"] === "door") {
                echo "<a href='{$element['link']}'><div class='door'></div></a>";
            } elseif ($element["type"] === "building") {
                echo "<div class='building'></div>";
            }
        }
    ;
    ?>
    </div>
</body>