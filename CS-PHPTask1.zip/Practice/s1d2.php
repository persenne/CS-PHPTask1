<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>Entering the second door, you find a Mini Meowrchant selling 2 unpredictable doors. Anything could happen within these two doors. Choose wisely.</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "door", "link" => "s1d21.php"],
        ["type" => "meowrchant"],
        ["type" => "door", "link" => "s1d22.php"]
    ];

    foreach ($elements as $element) {
        if ($element["type"] === "door") {
            echo "<a href='{$element['link']}'><div class='door'></div></a>";
        } elseif ($element["type"] === "meowrchant") {
            echo "<div class='meowrchant'></div>";
        }
    }
    ?>
    </div>
</body>