<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>As you enter the first door, a shiny yellow light greets you. Jewelry, gold, and alike are overflowing! You bring them back with you, and continue your journey to the capital.</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "gold"],
        ["type" => "door", "link" => "index.php"],
        ["type" => "gold"] ];


        foreach ($elements as $element) {
            if ($element["type"] === "door") {
                echo "<a href='{$element['link']}'><div class='door'></div></a>";
            } elseif ($element["type"] === "gold") {
                echo "<div class='gold'></div>";
            }
        }
    ;
    ?>
    </div>
</body>