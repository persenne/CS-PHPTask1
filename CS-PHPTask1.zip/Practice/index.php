<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>You had just arrived in Certacila and have lost your way after a sandstorm hit you! Three doors emerge infront of you leading to different areas. What will you do?</p>
    <div class="row">
    <?php
    $doors = [
        "s1d1.php",
        "s1d2.php",
        "s1d3.php"
    ];
    foreach ($doors as $link) {
        echo "<a href='$link'><div class='door'></div></a>";
    }
    ?>
    </div>
</body>
</html>