<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>As you enter the first door, you get burnt and dizzy immediately. There's.. fire djinns everywhere! Run!</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "fire"],
        ["type" => "door", "link" => "index.php"],
        ["type" => "fire"] ];


        foreach ($elements as $element) {
            if ($element["type"] === "door") {
                echo "<a href='{$element['link']}'><div class='door'></div></a>";
            } elseif ($element["type"] === "fire") {
                echo "<div class='fire'></div>";
            }
        }
    ;
    ?>
    </div>
</body>