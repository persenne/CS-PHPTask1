<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>As you enter the first door, you feel a dark feel on your body. There's no light. You've reached the.. outskirts! Time to go back!</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "destroyed"],
        ["type" => "door", "link" => "index.php"],
        ["type" => "destroyed"] ];


        foreach ($elements as $element) {
            if ($element["type"] === "door") {
                echo "<a href='{$element['link']}'><div class='door'></div></a>";
            } elseif ($element["type"] === "destroyed") {
                echo "<div class='destroyed'></div>";
            }
        }
    ;
    ?>
    </div>
</body>