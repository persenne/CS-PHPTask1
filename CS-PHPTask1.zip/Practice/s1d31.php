<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>You follow her into the first door, and the smell of flowers and honey fill the air. Nymphs and faeries surround the temporary oasis. You relax there for a bit before leaving on your journey.</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "fairy"],
        ["type" => "door", "link" => "index.php"],
        ["type" => "fairy"] ];


        foreach ($elements as $element) {
            if ($element["type"] === "door") {
                echo "<a href='{$element['link']}'><div class='door'></div></a>";
            } elseif ($element["type"] === "fairy") {
                echo "<div class='fairy'></div>";
            }
        }
    ;
    ?>
    </div>
</body>