<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>You follow her into the second door, and the future is so destructive! Unable to stand the chemicals and air quality, you run back before the door is closed.</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "environment"],
        ["type" => "door", "link" => "index.php"],
        ["type" => "environment"] ];


        foreach ($elements as $element) {
            if ($element["type"] === "door") {
                echo "<a href='{$element['link']}'><div class='door'></div></a>";
            } elseif ($element["type"] === "environment") {
                echo "<div class='environment'></div>";
            }
        }
    ;
    ?>
    </div>
</body>