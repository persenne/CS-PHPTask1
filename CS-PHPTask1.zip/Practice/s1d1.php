<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>Entering the first door, you find a mystical Shard of Indentation on the bottom of the floor. It possesses very dangerous power, causing 2 more doors to open. What do you enter?</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "door", "link" => "s1d11.php"],
        ["type" => "shard"],
        ["type" => "door", "link" => "s1d12.php"]
    ];

    foreach ($elements as $element) {
        if ($element["type"] === "door") {
            echo "<a href='{$element['link']}'><div class='door'></div></a>";
        } elseif ($element["type"] === "shard") {
            echo "<div class='shard'></div>";
        }
    }
    ?>
    </div>
</body>