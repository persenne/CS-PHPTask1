<!DOCTYPE html>
<head>
    <link rel="Stylesheet" href="styling.css">
</head>
<body>
    <p>Entering the third door, you are greeted by a mysterious woman. She says she is from the future and you have the option to follow her into the mystic or the future. What do you choose?</p>
    <div class="row">
    <?php
    $elements = [
        ["type" => "door", "link" => "s1d31.php"],
        ["type" => "woman"],
        ["type" => "door", "link" => "s1d32.php"]
    ];

    foreach ($elements as $element) {
        if ($element["type"] === "door") {
            echo "<a href='{$element['link']}'><div class='door'></div></a>";
        } elseif ($element["type"] === "woman") {
            echo "<div class='woman'></div>";
        }
    }
    ?>
    </div>
</body>